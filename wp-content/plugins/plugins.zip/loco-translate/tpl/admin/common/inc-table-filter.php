
    <form class="loco-filter" action="#">
        <fieldset class="loco-clearable">
            <input type="text" name="q" value="" autocomplete="off" placeholder="<?php esc_html_e('Filter list','loco')?>" size="20" />
        </fieldset>
    </form>
