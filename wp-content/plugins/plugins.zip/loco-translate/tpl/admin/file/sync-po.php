<?php
$this->extend('../layout');

?> 

    <h3 class="title">
        <span><?php $params->e('title')?></span>
    </h3>
