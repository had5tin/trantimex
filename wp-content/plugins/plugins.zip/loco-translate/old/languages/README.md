# Legacy versions translations

Many thanks to the translators of version 1.x


* Dutch translations by [Niels Geryl](http://hetwittepaard.be)
* German translations by [Sebastian König](http://aykutmania.de) and [Arno Welzel](https://wordpress.org/support/profile/awelzel)
* Turkish translations by [Abdullah Pazarbaşı](http://abdullahpazarbasi.com), Abdullah Manaz and [WordCommerce](http://www.wordcommerce.com/wordcommerce-iletisim/)
* Swedish translations by [Jimmy Malmqvist](http://jimmymalmqvist.com)
* Russian translations by [Alexey Tkachenko](http://atkachenko.ru) and Vyacheslav Stabrovsky
* Indonesian translations by [Ivan Lanin](https://twitter.com/ivanlanin)
* Italian translations by [ElectricFeet](http://wordpress.org/support/profile/electricfeet)
* Polish translations by [Jerry1333](http://www.jerry1333.net) and [Marek Sierociński](http://marek.sierocinscy.pl)
* Persian translations by [Araz Rad](http://fa.araz.id.ir)
* Japanese translations by [Agarthe LLC](https://agarthe.com)
* Spanish translations by [temesis1234](https://wordpress.org/support/profile/temesis1234)
* Brazilian Portuguese translations by [pamcabezas](https://github.com/pamcabezas) and [Marcelo Saldanha](http://www.associadosweb.com/)
* European Portuguese translations by [Pedro Mendonça](https://github.com/pedro-mendonca)
* French translations by [Borjan Tchakaloff](https://github.com/bibz)
* Korean translations by [Josh Kim](mailto:joshkkim@gmail.com)
* Ukrainian translations by [Dmitriy Malyuta](https://www.facebook.com/malyuta)
* Czech translations by [Martin Kokeš](https://twitter.com/zhr3k)
* Greek translations by [Stathis Mellios](mailto:mellios@live.com)
